package com.example.Helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping("/hello-world/welcome")
    public String welcome() {
        return "Welcome to LOIT";
    }
}
